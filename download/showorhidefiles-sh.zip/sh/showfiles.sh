#!/bin/sh
defaults write com.apple.finder AppleShowAllFiles -bool true
killall Finder
echo "设置显示所有隐藏文件成功！"