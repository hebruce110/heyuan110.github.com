#!/bin/sh
defaults write com.apple.finder AppleShowAllFiles -bool false
killall Finder
echo "设置不显示所有隐藏文件成功！"